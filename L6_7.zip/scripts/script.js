let basket = document.querySelector('.basket');
basket.insertAdjacentHTML('beforebegin', '<h1 class="title">Задание 6 + Задание 7</h1>');

basket.insertAdjacentHTML('afterbegin', '<div class="modal"></div>');
let modal = basket.querySelector('.modal');

modal.insertAdjacentHTML('afterbegin', '<div class="close">x</div>')
let close = modal.querySelector('.close');

modal.insertAdjacentHTML('afterbegin',
  '<button class="left"><</button>' +
  '<div class="modal_image">' +
  '<div class="imageTrack"></div>' +
  '</div>' +
  '<button class="right">></button>');

let modal_image = modal.querySelector('.modal_image');
let imageTrack = modal.querySelector('.imageTrack');
let left = modal.querySelector('.left');
let right = modal.querySelector('.right');

basket.insertAdjacentHTML('afterbegin', '<h2 class="basketTitle">Корзина</h2>');
let basketTitle = basket.querySelector('.basketTitle');

basketTitle.insertAdjacentHTML('afterend', '<p class="composition"></p>');
let composition = basket.querySelector('.composition');

basket.insertAdjacentHTML('beforeend', '<div class="catalog">catalog</div>');
let catalog = basket.querySelector('.catalog');

basket.insertAdjacentHTML('beforeend', '<button class="btnDel">УДАЛИТЬ</button>');
let btnDel = basket.querySelector('.btnDel');


let Products = [
  {
    productName: 'Телефон',
    productBrand: 'GRANDSTREAM',
    producrModel: 'GXP-1625',
    productDescription: 'Стандартный IP телефон, предназначенный для малого бизнеса.',
    productPrice: 3670
  },
  {
    productName: 'Ноутбук',
    productBrand: 'ASUS',
    producrModel: 'K56CB',
    productDescription: 'Asus 90NB0151-M07690 - это мощная система на базе Intel, позволяющая заменить полноценный стационарный компьютер. При скромных габаритах ноутбук обладает внушительными характеристиками. Отличное приобретение для офиса.',
    productPrice: 41600
  },
  {
    productName: 'МФУ струйное',
    productBrand: 'Canon',
    producrModel: 'Pixma MG2540S',
    productDescription: 'МФУ струйное Canon Pixma MG2540S – прекрасный выбор для дальнейшего использования дома. Вам необходимо универсальное устройство, которое способно выполнять несколько задач? Эта модель осуществляет печать, копирование и сканирование. Оно покроет основные потребности, можно уменьшить количество приобретаемого оборудования.',
    productPrice: 2699
  },
  {
    productName: 'Монитор',
    productBrand: 'DELL',
    producrModel: 'E2220H',
    productDescription: 'DELL E2220H – надежная черная модель для работы и учебы. Ее разрешение 1920х1080 пикселей позволяет с легкостью размещать на экране графики и таблицы. Хорошая контрастность 1000:1 помогает дольше работать за компьютером без усталости глаз. Использование светодиодной подсветки позволило снизить энергопотребление до 14 Вт.',
    productPrice: 3670
  }
];

let xPosition = 0; // Начальная позиция карусели

refreshBasket(Products);
compBasket(Products);

catalog.addEventListener('click', (e) => { // Вызов окна просмотра товаров
  imageTrack.textContent = '';
  let target = e.target;
  if (target.tagName != 'IMG') {
    return
  } else {
    let imgId = target.dataset.imageid;
    let imageTrackContent = '';
    for (let i = 1; i <= 3; i++) {
      imageTrackContent += `<img class="imgTrackContent" src="./img/tovar_${imgId}_${i}.png" alt="${imgId}_${i}" widht="600" height="600">`
    };
    imageTrack.insertAdjacentHTML('afterbegin', imageTrackContent);
    imageTrack.style.setProperty('transform', 'translateX(0)');
    xPosition = 0;
    modal.style.setProperty('visibility', 'visible');
  };
});

close.addEventListener('click', (e) => { // Скрытие окна просмотра
  imageTrack.textContent = '';
  imageTrack.style.setProperty('transform', 'translateX(0)');
  xPosition = 0;
  modal.style.setProperty('visibility', 'hidden');
});

left.addEventListener('click', (e) => { // Движение карусели влево
  xPosition++
  if (xPosition >= 1) {xPosition = 0;};
  moveImageTrack (xPosition);
});

right.addEventListener('click', (e) => { // Движение карусели вправо
  xPosition--
  if (xPosition <= -3) {xPosition = -2;};
  moveImageTrack (xPosition);
});

btnDel.addEventListener('click', (e) => { // Удаление объектов из корзины
  Products.pop();
  refreshBasket(Products);
  compBasket(Products);
  if (Products.length === 0) {
    composition.textContent = 'Корзина пуста';
    btnDel.setAttribute ('disabled', 'disabled');
  };
});

function refreshBasket(productsArr) { // Функция обновления корзины
  catalog.textContent = '';
  let productAdd = '';
  productsArr.forEach((item, i) => {
    productAdd += `
    <div class="productBlock" data-id="${i}">
      <div class="contentBlock">
        <p class="content" >Название товара: <span class="contentStrong">${item.productName}</span></p>
        <p class="content" >Бренд: <span class="contentStrong">${item.productBrand}</span></p>
        <p class="content" >Модель: <span class="contentStrong">${item.producrModel}</span></p>
        <p class="content" >Описание: <span class="contentStrong">${item.productDescription}</span></p>
        <p class="content" >Цена: <span class="contentStrong">${item.productPrice} руб.</span></p>
      </div>
      <img class="imageBlock" src="./img/tovar_${i + 1}_1.png" data-imageID = ${i + 1} alt="${item.producrModel}" width="250" height="250">
    </div>
    `;
  });
  catalog.insertAdjacentHTML('beforeend', productAdd);
};

function compBasket(productsArr) { // Функция пересчета корзины
  let count = productsArr.length;
  let price = 0;
  productsArr.forEach((item) => {
    price += item.productPrice
  });
  composition.textContent = `В корзине ${count} товара(ов) на сумму ${price} рублей`;
};

function moveImageTrack (x) { // Функция движение объектов в карусели
  imageTrack.style.setProperty('transform', 'translateX(' + (x * 600) + 'px)');
};